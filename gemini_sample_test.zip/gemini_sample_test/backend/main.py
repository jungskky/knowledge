import os
import google.generativeai as genai
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

# 1. Gemini API 설정
# 직접 입력하거나 환경 변수(os.environ.get)를 사용하세요.
GOOGLE_API_KEY = "AIzaSyAgDll_9HygKr9-9KNYNW4Wdz4fiFbPJKU"
genai.configure(api_key=GOOGLE_API_KEY)

app = FastAPI()

# CORS 설정 (React 연동)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class ChatRequest(BaseModel):
    message: str


# 2. Gemini 스트리밍 제너레이터
async def get_gemini_response(user_input: str):
    try:
        # 기존 코드
        # model = genai.GenerativeModel('gemini-1.5-pro')

        # 수정 제안 1 (가장 권장: 최신 안정판)
        #model = genai.GenerativeModel('gemini-1.5-pro-latest')

        # 수정 제안 2 (구체적인 버전 명시)
        #model = genai.GenerativeModel('models/gemini-1.5-pro')

        # 수정 제안 3 (속도가 빠른 Flash 모델로 테스트)
        model = genai.GenerativeModel('models/gemini-3.1-pro-preview')

        # 비동기 스트리밍 호출
        response = await model.generate_content_async(user_input, stream=True)

        async for chunk in response:
            if chunk.text:
                # 텍스트 조각을 즉시 yield
                yield chunk.text
    except Exception as e:
        yield f"Error: {str(e)}"


@app.post("/chat/stream")
async def chat_stream(request: ChatRequest):
    # StreamingResponse를 통해 프론트엔드로 조각별 전송
    return StreamingResponse(
        get_gemini_response(request.message),
        media_type="text/plain"
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)