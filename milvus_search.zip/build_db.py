"""Milvus 컬렉션 구축: BGE-M3 dense + Kiwi BM25 sparse 하이브리드 인덱싱."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from pymilvus import DataType, MilvusClient
from pymilvus.model.hybrid import BGEM3EmbeddingFunction
from pymilvus.model.sparse import BM25EmbeddingFunction

import config
from kiwi_analyzer import build_kiwi_analyzer
from milvus_lite_patch import apply_windows_manifest_patch
from sparse_utils import sparse_row_to_dict


def load_documents(data_path: Path) -> list[dict]:
    with data_path.open(encoding="utf-8") as file:
        documents = json.load(file)

    for index, doc in enumerate(documents):
        if "id" not in doc or "text" not in doc:
            raise ValueError(f"문서 {index}번에 id 또는 text 필드가 없습니다.")
    return documents


def create_bge_embedder() -> BGEM3EmbeddingFunction:
    return BGEM3EmbeddingFunction(
        model_name=config.BGE_MODEL_NAME,
        device=config.DEVICE,
        use_fp16=config.USE_FP16,
        return_dense=True,
        return_sparse=False,
    )


def create_bm25_embedder(corpus: list[str]) -> BM25EmbeddingFunction:
    analyzer = build_kiwi_analyzer()
    bm25_ef = BM25EmbeddingFunction(analyzer=analyzer, num_workers=1)
    bm25_ef.fit(corpus)
    return bm25_ef


def build_schema(client: MilvusClient, dense_dim: int):
    schema = client.create_schema(auto_id=False, enable_dynamic_field=False)
    schema.add_field(
        field_name=config.FIELD_ID,
        datatype=DataType.VARCHAR,
        is_primary=True,
        max_length=128,
    )
    schema.add_field(
        field_name=config.FIELD_TEXT,
        datatype=DataType.VARCHAR,
        max_length=config.TEXT_MAX_LENGTH,
    )
    schema.add_field(
        field_name=config.FIELD_EMBEDDING,
        datatype=DataType.FLOAT_VECTOR,
        dim=dense_dim,
    )
    schema.add_field(
        field_name=config.FIELD_EMBEDDING_BM25,
        datatype=DataType.SPARSE_FLOAT_VECTOR,
    )
    return schema


def build_index_params(client: MilvusClient):
    index_params = client.prepare_index_params()
    index_params.add_index(
        field_name=config.FIELD_EMBEDDING,
        index_type="AUTOINDEX",
        metric_type="IP",
    )
    index_params.add_index(
        field_name=config.FIELD_EMBEDDING_BM25,
        index_type="SPARSE_INVERTED_INDEX",
        metric_type="IP",
    )
    return index_params


def sparse_rows(sparse_matrix):
    for row_index in range(sparse_matrix.shape[0]):
        yield sparse_row_to_dict(sparse_matrix[row_index])


def build_rows(
    documents: list[dict],
    dense_embeddings: list,
    sparse_embeddings,
) -> list[dict]:
    rows = []
    for doc, dense_vector, sparse_vector in zip(
        documents,
        dense_embeddings,
        sparse_rows(sparse_embeddings),
    ):
        rows.append(
            {
                config.FIELD_ID: doc["id"],
                config.FIELD_TEXT: doc["text"],
                config.FIELD_EMBEDDING: dense_vector,
                config.FIELD_EMBEDDING_BM25: sparse_vector,
            }
        )
    return rows


def insert_documents(
    client: MilvusClient,
    rows: list[dict],
) -> None:
    for start in range(0, len(rows), config.INSERT_BATCH_SIZE):
        end = start + config.INSERT_BATCH_SIZE
        client.insert(config.COLLECTION_NAME, rows[start:end])


def build_database(data_path: Path, drop_existing: bool) -> None:
    documents = load_documents(data_path)
    texts = [doc["text"] for doc in documents]

    print(f"문서 {len(documents)}건 로드 완료")

    bge_ef = create_bge_embedder()
    dense_dim = bge_ef.dim["dense"]
    print(f"BGE-M3 dense 차원: {dense_dim}")

    print("Kiwi BM25 모델 학습 중...")
    bm25_ef = create_bm25_embedder(texts)

    print("임베딩 생성 중...")
    dense_result = bge_ef(texts)
    dense_embeddings = dense_result["dense"]
    sparse_embeddings = bm25_ef.encode_documents(texts)
    rows = build_rows(documents, dense_embeddings, sparse_embeddings)

    apply_windows_manifest_patch()
    client = MilvusClient(uri=config.MILVUS_URI)

    if client.has_collection(config.COLLECTION_NAME):
        if drop_existing:
            client.drop_collection(config.COLLECTION_NAME)
            print(f"기존 컬렉션 '{config.COLLECTION_NAME}' 삭제")
        else:
            raise RuntimeError(
                f"컬렉션 '{config.COLLECTION_NAME}'이 이미 존재합니다. "
                "--drop-existing 옵션을 사용하세요."
            )

    client.create_collection(
        collection_name=config.COLLECTION_NAME,
        schema=build_schema(client, dense_dim),
        index_params=build_index_params(client),
    )
    print(f"컬렉션 '{config.COLLECTION_NAME}' 생성")

    insert_documents(client, rows)
    print(f"데이터 삽입 완료: {len(rows)}건")

    config.BM25_MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    bm25_ef.save(str(config.BM25_MODEL_PATH))
    print(f"BM25 모델 저장: {config.BM25_MODEL_PATH}")
    print("DB 구축 완료")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Milvus 하이브리드 DB 구축")
    parser.add_argument(
        "--data",
        type=Path,
        default=Path("data/sample_documents.json"),
        help="id, text 필드를 포함한 JSON 문서 파일 경로",
    )
    parser.add_argument(
        "--drop-existing",
        action="store_true",
        help="기존 컬렉션이 있으면 삭제 후 재생성",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    build_database(args.data, args.drop_existing)
