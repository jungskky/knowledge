"""Milvus 하이브리드 검색: BGE-M3 dense + Kiwi BM25 sparse."""

from __future__ import annotations

import argparse

from pymilvus import AnnSearchRequest, MilvusClient, RRFRanker, WeightedRanker
from pymilvus.model.hybrid import BGEM3EmbeddingFunction
from pymilvus.model.sparse import BM25EmbeddingFunction

import config
from kiwi_bm25 import encode_query as encode_bm25_query, load_bm25_embedder
from milvus_lite_patch import apply_windows_manifest_patch


def get_client() -> MilvusClient:
    apply_windows_manifest_patch()
    client = MilvusClient(uri=config.MILVUS_URI)
    if not client.has_collection(config.COLLECTION_NAME):
        raise RuntimeError(
            f"컬렉션 '{config.COLLECTION_NAME}'이 없습니다. "
            "먼저 build_db.py를 실행하세요."
        )
    client.load_collection(config.COLLECTION_NAME)
    return client


def load_embedders() -> tuple[BGEM3EmbeddingFunction, BM25EmbeddingFunction]:
    if not config.BM25_MODEL_PATH.exists():
        raise FileNotFoundError(
            f"BM25 모델 파일이 없습니다: {config.BM25_MODEL_PATH}\n"
            "먼저 build_db.py를 실행하세요."
        )

    bge_ef = BGEM3EmbeddingFunction(
        model_name=config.BGE_MODEL_NAME,
        device=config.DEVICE,
        use_fp16=config.USE_FP16,
        return_dense=True,
        return_sparse=False,
    )

    bm25_ef = load_bm25_embedder(config.BM25_MODEL_PATH)

    return bge_ef, bm25_ef


def encode_query(
    query: str,
    bge_ef: BGEM3EmbeddingFunction,
    bm25_ef: BM25EmbeddingFunction,
) -> tuple[list[float], object]:
    dense_embedding = bge_ef.encode_queries([query])["dense"][0]
    sparse_embedding = encode_bm25_query(query, bm25_ef)
    return dense_embedding, sparse_embedding


def dense_search(
    client: MilvusClient,
    query_dense_embedding: list[float],
    limit: int,
) -> list[dict]:
    results = client.search(
        collection_name=config.COLLECTION_NAME,
        data=[query_dense_embedding],
        anns_field=config.FIELD_EMBEDDING,
        search_params={"metric_type": "IP", "params": {}},
        limit=limit,
        output_fields=[config.FIELD_ID, config.FIELD_TEXT],
    )[0]
    return _hits_to_dicts(results)


def sparse_search(
    client: MilvusClient,
    query_sparse_embedding,
    limit: int,
) -> list[dict]:
    results = client.search(
        collection_name=config.COLLECTION_NAME,
        data=[query_sparse_embedding],
        anns_field=config.FIELD_EMBEDDING_BM25,
        search_params={"metric_type": "IP", "params": {}},
        limit=limit,
        output_fields=[config.FIELD_ID, config.FIELD_TEXT],
    )[0]
    return _hits_to_dicts(results)


def hybrid_search(
    client: MilvusClient,
    query_dense_embedding: list[float],
    query_sparse_embedding,
    limit: int,
    sparse_weight: float,
    dense_weight: float,
    use_rrf: bool,
) -> list[dict]:
    dense_req = AnnSearchRequest(
        data=[query_dense_embedding],
        anns_field=config.FIELD_EMBEDDING,
        param={"metric_type": "IP", "params": {}},
        limit=limit,
    )
    sparse_req = AnnSearchRequest(
        data=[query_sparse_embedding],
        anns_field=config.FIELD_EMBEDDING_BM25,
        param={"metric_type": "IP", "params": {}},
        limit=limit,
    )

    rerank = RRFRanker() if use_rrf else WeightedRanker(sparse_weight, dense_weight)
    results = client.hybrid_search(
        collection_name=config.COLLECTION_NAME,
        reqs=[sparse_req, dense_req],
        ranker=rerank,
        limit=limit,
        output_fields=[config.FIELD_ID, config.FIELD_TEXT],
    )[0]
    return _hits_to_dicts(results)


def _hits_to_dicts(hits) -> list[dict]:
    return [
        {
            "id": hit["entity"][config.FIELD_ID],
            "text": hit["entity"][config.FIELD_TEXT],
            "score": hit["distance"],
        }
        for hit in hits
    ]


def print_results(title: str, results: list[dict]) -> None:
    print(f"\n=== {title} ({len(results)}건) ===")
    if not results:
        print("결과 없음")
        return

    for rank, item in enumerate(results, start=1):
        print(f"[{rank}] id={item['id']} score={item['score']:.4f}")
        print(f"     {item['text']}")


def run_search(
    query: str,
    mode: str,
    top_k: int,
    sparse_weight: float,
    dense_weight: float,
    use_rrf: bool,
) -> None:
    client = get_client()
    bge_ef, bm25_ef = load_embedders()
    dense_embedding, sparse_embedding = encode_query(query, bge_ef, bm25_ef)

    if mode == "dense":
        results = dense_search(client, dense_embedding, top_k)
        print_results("Dense 검색 (BGE-M3)", results)
    elif mode == "sparse":
        results = sparse_search(client, sparse_embedding, top_k)
        print_results("Sparse 검색 (Kiwi BM25)", results)
    elif mode == "hybrid":
        results = hybrid_search(
            client,
            dense_embedding,
            sparse_embedding,
            top_k,
            sparse_weight,
            dense_weight,
            use_rrf,
        )
        rerank_name = "RRF" if use_rrf else f"Weighted({sparse_weight}, {dense_weight})"
        print_results(f"Hybrid 검색 ({rerank_name})", results)
    else:
        raise ValueError(f"지원하지 않는 검색 모드: {mode}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Milvus 하이브리드 검색")
    parser.add_argument("query", help="검색 쿼리")
    parser.add_argument(
        "--mode",
        choices=["dense", "sparse", "hybrid"],
        default="hybrid",
        help="검색 모드 (기본: hybrid)",
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=config.DEFAULT_TOP_K,
        help=f"반환할 결과 수 (기본: {config.DEFAULT_TOP_K})",
    )
    parser.add_argument(
        "--sparse-weight",
        type=float,
        default=config.DEFAULT_SPARSE_WEIGHT,
        help="하이브리드 검색 sparse 가중치",
    )
    parser.add_argument(
        "--dense-weight",
        type=float,
        default=config.DEFAULT_DENSE_WEIGHT,
        help="하이브리드 검색 dense 가중치",
    )
    parser.add_argument(
        "--rrf",
        action="store_true",
        help="WeightedRanker 대신 RRFRanker 사용",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    run_search(
        query=args.query,
        mode=args.mode,
        top_k=args.top_k,
        sparse_weight=args.sparse_weight,
        dense_weight=args.dense_weight,
        use_rrf=args.rrf,
    )
