"""Kiwi 형태소 분석 + BM25 sparse embedding 처리 모듈."""

from __future__ import annotations

from pathlib import Path

from pymilvus.model.sparse import BM25EmbeddingFunction
from pymilvus.model.sparse.bm25.tokenizers import Analyzer, KiwiTokenizer

_DEFAULT_ANALYZER: Analyzer | None = None


def build_kiwi_analyzer() -> Analyzer:
    """Kiwi 형태소 분석기 기반 BM25용 Analyzer를 생성합니다."""
    return Analyzer(
        name="kiwi",
        tokenizer=KiwiTokenizer(),
        preprocessors=[],
        filters=[],
    )


def get_kiwi_analyzer() -> Analyzer:
    """재사용 가능한 Kiwi Analyzer 싱글톤을 반환합니다."""
    global _DEFAULT_ANALYZER
    if _DEFAULT_ANALYZER is None:
        _DEFAULT_ANALYZER = build_kiwi_analyzer()
    return _DEFAULT_ANALYZER


def tokenize(text: str, analyzer: Analyzer | None = None) -> list[str]:
    """Kiwi로 텍스트를 형태소 단위 토큰 리스트로 변환합니다."""
    return (analyzer or get_kiwi_analyzer())(text)


def sparse_row_to_dict(row) -> dict[int, float]:
    """BM25 sparse vector를 Milvus 삽입/검색용 dict 형식으로 변환합니다."""
    if isinstance(row, dict):
        return row
    if row.ndim == 1:
        indices = row.nonzero()[0]
        return {int(index): float(row[index]) for index in indices}
    return {int(index): float(row[0, index]) for index in row.indices}


def create_bm25_embedder(
    corpus: list[str],
    *,
    k1: float = 1.5,
    b: float = 0.75,
    num_workers: int = 1,
) -> BM25EmbeddingFunction:
    """코퍼스로 Kiwi BM25 모델을 학습(fit)합니다."""
    bm25_ef = BM25EmbeddingFunction(
        analyzer=get_kiwi_analyzer(),
        k1=k1,
        b=b,
        num_workers=num_workers,
    )
    bm25_ef.fit(corpus)
    return bm25_ef


def load_bm25_embedder(model_path: str | Path) -> BM25EmbeddingFunction:
    """저장된 Kiwi BM25 모델 통계(idf 등)를 로드합니다."""
    path = Path(model_path)
    if not path.exists():
        raise FileNotFoundError(f"BM25 모델 파일이 없습니다: {path}")

    bm25_ef = BM25EmbeddingFunction(analyzer=get_kiwi_analyzer(), num_workers=1)
    bm25_ef.load(str(path))
    return bm25_ef


def save_bm25_embedder(bm25_ef: BM25EmbeddingFunction, model_path: str | Path) -> Path:
    """학습된 Kiwi BM25 모델 통계를 저장합니다."""
    path = Path(model_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    bm25_ef.save(str(path))
    return path


def encode_documents(
    texts: list[str],
    bm25_ef: BM25EmbeddingFunction,
) -> list[dict[int, float]]:
    """문서 텍스트 리스트를 Kiwi BM25 sparse vector dict 리스트로 변환합니다."""
    sparse_matrix = bm25_ef.encode_documents(texts)
    return [sparse_row_to_dict(sparse_matrix[row_index]) for row_index in range(sparse_matrix.shape[0])]


def encode_query(query: str, bm25_ef: BM25EmbeddingFunction) -> dict[int, float]:
    """쿼리 텍스트를 Kiwi BM25 sparse vector dict로 변환합니다."""
    sparse_matrix = bm25_ef.encode_queries([query])
    return sparse_row_to_dict(sparse_matrix[0])
