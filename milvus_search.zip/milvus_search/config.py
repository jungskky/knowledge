from pathlib import Path

# Milvus 연결 설정
# - 로컬 파일(./milvus.db): Milvus Lite 사용
# - Docker/클러스터: http://localhost:19530 형태의 URI 사용
MILVUS_URI = "./milvus.db"
COLLECTION_NAME = "hybrid_collection"

# 컬럼명
FIELD_ID = "id"
FIELD_TEXT = "text"
FIELD_EMBEDDING = "embedding"
FIELD_EMBEDDING_BM25 = "embedding_bm25"

# 모델 설정
BGE_MODEL_NAME = "BAAI/bge-m3"
DEVICE = "cpu"
USE_FP16 = False
TEXT_MAX_LENGTH = 65535
INSERT_BATCH_SIZE = 50

# BM25 모델 저장 경로 (구축 시 fit 결과, 조회 시 로드)
BM25_MODEL_PATH = Path("./models/bm25_model.json")

# 하이브리드 검색 기본 가중치 (sparse, dense)
DEFAULT_SPARSE_WEIGHT = 1.0
DEFAULT_DENSE_WEIGHT = 1.0
DEFAULT_TOP_K = 10
