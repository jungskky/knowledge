import os
import sys


def apply_windows_manifest_patch() -> None:
    """milvus-lite가 Windows에서 두 번째 인덱스 생성 시 실패하는 문제를 우회합니다."""
    if sys.platform != "win32":
        return

    from milvus_lite.storage.manifest import Manifest

    if getattr(Manifest.save, "_windows_patched", False):
        return

    original_save = Manifest.save

    def patched_save(self) -> None:
        real_rename = os.rename
        os.rename = os.replace
        try:
            original_save(self)
        finally:
            os.rename = real_rename

    patched_save._windows_patched = True
    Manifest.save = patched_save
