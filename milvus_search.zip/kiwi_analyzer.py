from pymilvus.model.sparse.bm25.tokenizers import Analyzer, KiwiTokenizer


def build_kiwi_analyzer() -> Analyzer:
    """Kiwi 형태소 분석기 기반 BM25용 Analyzer를 생성합니다."""
    return Analyzer(
        name="kiwi",
        tokenizer=KiwiTokenizer(),
        preprocessors=[],
        filters=[],
    )
