def sparse_row_to_dict(row) -> dict[int, float]:
    if isinstance(row, dict):
        return row
    if row.ndim == 1:
        indices = row.nonzero()[0]
        return {int(index): float(row[index]) for index in indices}
    return {int(index): float(row[0, index]) for index in row.indices}
