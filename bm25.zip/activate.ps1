# 프로젝트 venv314 활성화 (PowerShell)
& "$PSScriptRoot\venv314\Scripts\Activate.ps1"
