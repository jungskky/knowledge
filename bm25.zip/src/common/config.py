from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parents[2]
ENV_PATH = PROJECT_ROOT / ".env"


def load_env() -> None:
    load_dotenv(ENV_PATH)


def get_openai_api_key() -> str:
    load_env()
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    if not api_key:
        raise ValueError(
            f"OPENAI_API_KEY가 설정되지 않았습니다. {ENV_PATH} 파일을 확인하세요."
        )
    return api_key


def get_openai_base_url() -> str | None:
    load_env()
    base_url = os.getenv("OPENAI_BASE_URL", "").strip()
    return base_url or None


def get_openai_model() -> str:
    load_env()
    return os.getenv("OPENAI_MODEL", "gemini-3-flash-preview").strip()
