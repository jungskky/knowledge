from __future__ import annotations

import re


def tokenize(text: str) -> list[str]:
    """BM25용 경량 토크나이저 (영문·숫자·한글 음절)."""
    lowered = text.lower()
    return re.findall(r"[a-z0-9]+|[가-힣]", lowered)


def document_text(doc: dict) -> str:
    return f"{doc['title']} {doc['text']}"
