from __future__ import annotations

from openai import OpenAI

from src.common.config import get_openai_api_key, get_openai_base_url, get_openai_model


def get_client() -> OpenAI:
    return OpenAI(
        api_key=get_openai_api_key(),
        base_url=get_openai_base_url(),
    )


def generate_rag_answer(query: str, context: str, rag_type: str) -> str:
    """검색 컨텍스트와 .env의 Gemini 모델로 최종 답변 생성."""
    client = get_client()
    model = get_openai_model()

    response = client.chat.completions.create(
        model=model,
        messages=[
            {
                "role": "system",
                "content": (
                    f"당신은 {rag_type} 검색 결과를 바탕으로 질문에 답하는 assistant입니다. "
                    "제공된 컨텍스트만 사용하고, 근거가 없으면 모른다고 답하세요. "
                    "답변은 한국어로 간결하게 작성하세요."
                ),
            },
            {
                "role": "user",
                "content": f"질문: {query}\n\n컨텍스트:\n{context}",
            },
        ],
    )

    message = response.choices[0].message.content
    return message.strip() if message else ""
