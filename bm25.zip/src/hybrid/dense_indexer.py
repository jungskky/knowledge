from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from sentence_transformers import SentenceTransformer

from src.common.tokenizer import document_text


@dataclass
class DenseSearchResult:
    doc_id: str
    title: str
    text: str
    score: float
    rank: int


class DenseIndexer:
    """임베딩 기반 dense search (코사인 유사도)."""

    def __init__(
        self,
        documents: list[dict],
        model_name: str = "paraphrase-multilingual-MiniLM-L12-v2",
    ) -> None:
        self.documents = documents
        self.model = SentenceTransformer(model_name)
        texts = [document_text(doc) for doc in documents]
        self._embeddings = np.asarray(
            self.model.encode(texts, normalize_embeddings=True),
            dtype=np.float32,
        )

    def search(self, query: str, top_k: int = 5) -> list[DenseSearchResult]:
        query_vec = self.model.encode([query], normalize_embeddings=True)[0]
        scores = self._embeddings @ np.asarray(query_vec, dtype=np.float32)
        ranked = np.argsort(scores)[::-1][:top_k]

        results: list[DenseSearchResult] = []
        for rank, idx in enumerate(ranked, start=1):
            score = float(scores[idx])
            if score <= 0:
                continue
            doc = self.documents[idx]
            results.append(
                DenseSearchResult(
                    doc_id=doc["id"],
                    title=doc["title"],
                    text=doc["text"],
                    score=score,
                    rank=rank,
                )
            )
        return results
