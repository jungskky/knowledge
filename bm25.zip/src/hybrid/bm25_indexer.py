from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from rank_bm25 import BM25Okapi

from src.common.tokenizer import document_text, tokenize


@dataclass
class BM25SearchResult:
    doc_id: str
    title: str
    text: str
    score: float
    rank: int


class BM25Indexer:
    """키워드 기반 sparse search (BM25)."""

    def __init__(self, documents: list[dict]) -> None:
        self.documents = documents
        corpus = [tokenize(document_text(doc)) for doc in documents]
        self._bm25 = BM25Okapi(corpus)

    def search(self, query: str, top_k: int = 5) -> list[BM25SearchResult]:
        tokens = tokenize(query)
        scores = self._bm25.get_scores(tokens)
        ranked = np.argsort(scores)[::-1][:top_k]

        results: list[BM25SearchResult] = []
        for rank, idx in enumerate(ranked, start=1):
            score = float(scores[idx])
            if score <= 0:
                continue
            doc = self.documents[idx]
            results.append(
                BM25SearchResult(
                    doc_id=doc["id"],
                    title=doc["title"],
                    text=doc["text"],
                    score=score,
                    rank=rank,
                )
            )
        return results
