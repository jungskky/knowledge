from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass


@dataclass
class FusedDocument:
    doc_id: str
    title: str
    text: str
    fused_score: float
    dense_rank: int | None
    bm25_rank: int | None
    dense_score: float | None
    bm25_score: float | None


def reciprocal_rank_fusion(
    ranked_doc_ids: list[list[str]],
    documents_by_id: dict[str, dict],
    *,
    k: int = 60,
    top_k: int = 5,
) -> list[FusedDocument]:
    """
    Reciprocal Rank Fusion (RRF).

    score(d) = sum_i 1 / (k + rank_i(d))
    """
    fused_scores: dict[str, float] = defaultdict(float)
    rank_maps: list[dict[str, int]] = []

    for ranking in ranked_doc_ids:
        rank_map = {doc_id: rank for rank, doc_id in enumerate(ranking, start=1)}
        rank_maps.append(rank_map)
        for doc_id, rank in rank_map.items():
            fused_scores[doc_id] += 1.0 / (k + rank)

    ordered = sorted(fused_scores.items(), key=lambda item: item[1], reverse=True)[
        :top_k
    ]

    results: list[FusedDocument] = []
    for doc_id, fused_score in ordered:
        doc = documents_by_id[doc_id]
        dense_rank = rank_maps[0].get(doc_id) if len(rank_maps) > 0 else None
        bm25_rank = rank_maps[1].get(doc_id) if len(rank_maps) > 1 else None
        results.append(
            FusedDocument(
                doc_id=doc_id,
                title=doc["title"],
                text=doc["text"],
                fused_score=fused_score,
                dense_rank=dense_rank,
                bm25_rank=bm25_rank,
                dense_score=None,
                bm25_score=None,
            )
        )
    return results


def weighted_score_fusion(
    dense_results: list,
    bm25_results: list,
    documents_by_id: dict[str, dict],
    *,
    dense_weight: float = 0.5,
    bm25_weight: float = 0.5,
    top_k: int = 5,
) -> list[FusedDocument]:
    """정규화 점수의 가중 합 (dense + bm25)."""
    dense_max = max((r.score for r in dense_results), default=1.0) or 1.0
    bm25_max = max((r.score for r in bm25_results), default=1.0) or 1.0

    combined: dict[str, tuple[float, int | None, int | None, float | None, float | None]] = (
        {}
    )

    for item in dense_results:
        norm = item.score / dense_max
        combined[item.doc_id] = (
            dense_weight * norm,
            item.rank,
            None,
            item.score,
            None,
        )

    for item in bm25_results:
        norm = item.score / bm25_max
        if item.doc_id in combined:
            prev, d_rank, _, d_score, _ = combined[item.doc_id]
            combined[item.doc_id] = (
                prev + bm25_weight * norm,
                d_rank,
                item.rank,
                d_score,
                item.score,
            )
        else:
            combined[item.doc_id] = (
                bm25_weight * norm,
                None,
                item.rank,
                None,
                item.score,
            )

    ordered = sorted(combined.items(), key=lambda item: item[1][0], reverse=True)[
        :top_k
    ]

    results: list[FusedDocument] = []
    for doc_id, (fused_score, d_rank, b_rank, d_score, b_score) in ordered:
        doc = documents_by_id[doc_id]
        results.append(
            FusedDocument(
                doc_id=doc_id,
                title=doc["title"],
                text=doc["text"],
                fused_score=fused_score,
                dense_rank=d_rank,
                bm25_rank=b_rank,
                dense_score=d_score,
                bm25_score=b_score,
            )
        )
    return results
