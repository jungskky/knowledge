from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from src.hybrid.bm25_indexer import BM25Indexer, BM25SearchResult
from src.hybrid.dense_indexer import DenseIndexer, DenseSearchResult
from src.hybrid.fusion import FusedDocument, reciprocal_rank_fusion, weighted_score_fusion

FusionMethod = Literal["rrf", "weighted"]


@dataclass
class HybridSearchResponse:
    query: str
    fusion: FusionMethod
    dense_results: list[DenseSearchResult]
    bm25_results: list[BM25SearchResult]
    fused_results: list[FusedDocument]

    def to_context(self, top_k: int = 3) -> str:
        chunks = [
            f"[{item.title}] (fused={item.fused_score:.4f}, "
            f"dense_rank={item.dense_rank}, bm25_rank={item.bm25_rank})\n{item.text}"
            for item in self.fused_results[:top_k]
        ]
        return "\n\n".join(chunks) if chunks else "관련 문서를 찾지 못했습니다."


class HybridSearchEngine:
    """Dense(embedding) + BM25 하이브리드 검색."""

    def __init__(
        self,
        documents: list[dict],
        *,
        embedding_model: str = "paraphrase-multilingual-MiniLM-L12-v2",
    ) -> None:
        self.documents = documents
        self._documents_by_id = {doc["id"]: doc for doc in documents}
        self.dense = DenseIndexer(documents, model_name=embedding_model)
        self.bm25 = BM25Indexer(documents)

    def search(
        self,
        query: str,
        *,
        top_k: int = 5,
        fusion: FusionMethod = "rrf",
        dense_weight: float = 0.5,
        bm25_weight: float = 0.5,
        rrf_k: int = 60,
    ) -> HybridSearchResponse:
        dense_results = self.dense.search(query, top_k=top_k)
        bm25_results = self.bm25.search(query, top_k=top_k)

        if fusion == "rrf":
            fused = reciprocal_rank_fusion(
                [
                    [r.doc_id for r in dense_results],
                    [r.doc_id for r in bm25_results],
                ],
                self._documents_by_id,
                k=rrf_k,
                top_k=top_k,
            )
            for item in fused:
                for dense in dense_results:
                    if dense.doc_id == item.doc_id:
                        item.dense_score = dense.score
                        break
                for sparse in bm25_results:
                    if sparse.doc_id == item.doc_id:
                        item.bm25_score = sparse.score
                        break
        else:
            fused = weighted_score_fusion(
                dense_results,
                bm25_results,
                self._documents_by_id,
                dense_weight=dense_weight,
                bm25_weight=bm25_weight,
                top_k=top_k,
            )

        return HybridSearchResponse(
            query=query,
            fusion=fusion,
            dense_results=dense_results,
            bm25_results=bm25_results,
            fused_results=fused,
        )
