#!/usr/bin/env python3
"""Dense(embedding) + BM25 하이브리드 검색 데모."""

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.common.config import get_openai_model
from src.common.llm import generate_rag_answer
from src.common.sample_data import DOCUMENTS, SAMPLE_QUERIES
from src.hybrid.query import HybridSearchEngine


def print_section(title: str) -> None:
    print(f"\n=== {title} ===")


def main() -> None:
    parser = argparse.ArgumentParser(description="Hybrid dense + BM25 search demo")
    parser.add_argument("query", nargs="*", help="검색 질의")
    parser.add_argument(
        "--fusion",
        choices=["rrf", "weighted"],
        default="rrf",
        help="결합 방식 (기본: rrf)",
    )
    parser.add_argument("--top-k", type=int, default=3, help="각 검색기 Top-K")
    parser.add_argument(
        "--dense-weight",
        type=float,
        default=0.5,
        help="weighted 결합 시 dense 가중치",
    )
    parser.add_argument(
        "--bm25-weight",
        type=float,
        default=0.5,
        help="weighted 결합 시 bm25 가중치",
    )
    parser.add_argument(
        "--no-llm",
        action="store_true",
        help="검색만 수행하고 LLM 답변 생성 생략",
    )
    args = parser.parse_args()

    query = " ".join(args.query) if args.query else SAMPLE_QUERIES[0]
    engine = HybridSearchEngine(DOCUMENTS)
    response = engine.search(
        query,
        top_k=args.top_k,
        fusion=args.fusion,
        dense_weight=args.dense_weight,
        bm25_weight=args.bm25_weight,
    )

    print("=== Hybrid Search (Dense + BM25) ===")
    print(f"질의: {response.query}")
    print(f"결합: {response.fusion}")
    if not args.no_llm:
        print(f"모델: {get_openai_model()}")

    print_section("Dense (Embedding)")
    for item in response.dense_results:
        print(f"  [{item.rank}] {item.title} (score={item.score:.4f})")

    print_section("BM25 (Sparse)")
    for item in response.bm25_results:
        print(f"  [{item.rank}] {item.title} (score={item.score:.4f})")

    print_section("Fused")
    for rank, item in enumerate(response.fused_results, start=1):
        print(
            f"  [{rank}] {item.title} (fused={item.fused_score:.4f}, "
            f"dense_rank={item.dense_rank}, bm25_rank={item.bm25_rank})"
        )

    context = response.to_context(top_k=args.top_k)
    print_section("RAG 컨텍스트")
    print(context)

    if args.no_llm:
        return

    print_section("LLM 답변 (Gemini)")
    answer = generate_rag_answer(
        response.query,
        context,
        "Hybrid RAG (Dense + BM25)",
    )
    print(answer)


if __name__ == "__main__":
    main()
