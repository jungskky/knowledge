#!/usr/bin/env python3
"""동일 질의에 대해 dense / bm25 / hybrid 결과를 비교."""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.common.sample_data import DOCUMENTS, SAMPLE_QUERIES
from src.hybrid.bm25_indexer import BM25Indexer
from src.hybrid.dense_indexer import DenseIndexer
from src.hybrid.query import HybridSearchEngine


def top_titles(results, attr: str = "title") -> list[str]:
    return [getattr(item, attr) for item in results]


def main() -> None:
    query = " ".join(sys.argv[1:]) if len(sys.argv) > 1 else SAMPLE_QUERIES[0]
    top_k = 3

    dense = DenseIndexer(DOCUMENTS)
    bm25 = BM25Indexer(DOCUMENTS)
    hybrid = HybridSearchEngine(DOCUMENTS)

    dense_hits = dense.search(query, top_k=top_k)
    bm25_hits = bm25.search(query, top_k=top_k)
    hybrid_hits = hybrid.search(query, top_k=top_k, fusion="rrf")

    print(f"질의: {query}\n")
    print(f"Dense only : {top_titles(dense_hits)}")
    print(f"BM25 only  : {top_titles(bm25_hits)}")
    print(f"Hybrid RRF : {top_titles(hybrid_hits.fused_results)}")


if __name__ == "__main__":
    main()
