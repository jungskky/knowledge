# Hybrid Search Sample (Dense + BM25)

RAG용 **임베딩 검색(dense)** 과 **BM25(sparse)** 를 결합한 하이브리드 검색 샘플입니다.

## 구조

| 경로 | 역할 |
|------|------|
| `src/hybrid/dense_indexer.py` | Sentence-Transformer 임베딩 + 코사인 유사도 |
| `src/hybrid/bm25_indexer.py` | BM25Okapi 키워드 검색 |
| `src/hybrid/fusion.py` | RRF / 가중 점수 결합 |
| `src/hybrid/query.py` | 하이브리드 검색 API |
| `scripts/run_hybrid_search.py` | 단일 질의 데모 |
| `scripts/compare_search.py` | dense vs bm25 vs hybrid 비교 |

## 설치

Windows에서 `python`이 인식되지 않으면 **설정 → 앱 → 앱 실행 별칭**에서  
`python.exe` / `python3.exe` Store 별칭을 끄거나, 아래 `venv314`를 사용하세요.

```powershell
# PowerShell: 프로젝트 venv 활성화
.\activate.ps1

pip install -r requirements.txt
copy .env.example .env   # API 키 등 설정
```

Cursor/VS Code는 `.vscode/settings.json`으로 `venv314`를 자동 선택합니다.

`.env` 예시 (Gemini OpenAI 호환 API):

```env
OPENAI_API_KEY=your-gemini-api-key
OPENAI_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai/
OPENAI_MODEL=gemini-3-flash-preview
```

첫 실행 시 `paraphrase-multilingual-MiniLM-L12-v2` 임베딩 모델이 자동 다운로드됩니다.

## 실행

```bash
# 하이브리드 검색 + Gemini 답변 (기본 RRF)
python scripts/run_hybrid_search.py "프로덕션 배포 승인 절차"

# 검색만 (LLM 생략)
python scripts/run_hybrid_search.py "프로덕션 배포 승인 절차" --no-llm

# 가중 점수 결합
python scripts/run_hybrid_search.py "CTO 긴급 배포" --fusion weighted --dense-weight 0.6 --bm25-weight 0.4

# 검색기별 Top-K 비교
python scripts/compare_search.py "결제 서비스 장애 대응"
```

## 결합 방식

1. **RRF (기본)** — 순위만 사용, 점수 스케일 차이에 강함  
   `score(d) = Σ 1/(k + rank_i(d))`, `k=60`

2. **Weighted** — dense·bm25 점수를 각각 정규화 후 가중 합

## RAG 파이프라인에서의 위치

```
질의 → [Dense Top-K] ─┐
                      ├→ Fusion → Top-K 청크 → Gemini (generate_rag_answer)
      → [BM25 Top-K] ─┘
```

| 파일 | 역할 |
|------|------|
| `src/common/config.py` | `.env` 로드 (API 키, base URL, 모델) |
| `src/common/llm.py` | OpenAI SDK로 Gemini 호출 |

- **Dense**: 의미가 비슷한 문서 (동의어, paraphrase)
- **BM25**: 정확한 키워드·고유명사 (프로젝트명, 역할명)
- **Hybrid**: 두 신호를 보완해 recall 향상

## 커스터마이징

- 문서: `src/common/sample_data.py`의 `DOCUMENTS`
- 임베딩 모델: `HybridSearchEngine(..., embedding_model="...")`
- 한국어 형태소 분석이 필요하면 `src/common/tokenizer.py`를 교체하세요.
