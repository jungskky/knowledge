import pytest

from skill_sample.commit_skill import validate_commit_message


@pytest.mark.parametrize(
    "msg",
    [
        "feat(auth): add login",
        "fix(api): handle empty query string\n\nReturn 400.",
        "docs(readme): describe install steps",
    ],
)
def test_valid_messages(msg: str) -> None:
    r = validate_commit_message(msg)
    assert r.ok, r.errors


@pytest.mark.parametrize(
    ("msg", "snippet"),
    [
        ("", "empty"),
        ("bad", "First line must match"),
        ("feat: no scope\n", "First line must match"),
        ("unknown(x): y\n", "type must be one of"),
        ("feat(a): " + "x" * 73 + "\n", "at most 72"),
        ("feat(a): subject.\n", "period"),
        ("feat(a): subject\nnot blank\n", "Second line must be blank"),
    ],
)
def test_invalid_messages(msg: str, snippet: str) -> None:
    r = validate_commit_message(msg)
    assert not r.ok
    assert any(snippet in e for e in r.errors), r.errors
