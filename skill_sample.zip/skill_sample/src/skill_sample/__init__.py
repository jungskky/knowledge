"""Sample package: commit message rules shared with .cursor/skills/commit-message-format."""

from skill_sample.commit_skill import CommitValidationResult, validate_commit_message

__all__ = ["CommitValidationResult", "validate_commit_message"]
