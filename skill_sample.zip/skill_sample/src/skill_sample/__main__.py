"""CLI: validate commit message from stdin (for quick manual checks)."""

import sys

from skill_sample.commit_skill import validate_commit_message


def main() -> int:
    text = sys.stdin.read()
    r = validate_commit_message(text)
    if r.ok:
        print("OK")
        return 0
    for e in r.errors:
        print(e, file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
