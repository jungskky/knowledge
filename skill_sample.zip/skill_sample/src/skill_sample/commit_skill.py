from __future__ import annotations

import re
from dataclasses import dataclass

# Mirrors .cursor/skills/commit-message-format/SKILL.md
ALLOWED_TYPES = frozenset(
    {"feat", "fix", "docs", "chore", "test", "refactor"},
)

_HEADER_RE = re.compile(
    r"^(?P<type>[a-z]+)\((?P<scope>[a-z0-9-]{1,32})\): (?P<subject>.+)$"
)


@dataclass(frozen=True)
class CommitValidationResult:
    ok: bool
    errors: tuple[str, ...]


def validate_commit_message(text: str) -> CommitValidationResult:
    """Validate a full commit message string (header + optional body)."""
    errors: list[str] = []
    stripped = text.strip("\n")
    if not stripped:
        return CommitValidationResult(False, ("Commit message is empty.",))

    lines = stripped.splitlines()
    first = lines[0].strip()
    m = _HEADER_RE.match(first)
    if not m:
        errors.append(
            "First line must match: <type>(<scope>): <subject> "
            "(scope: lowercase letters, numbers, hyphens, 1–32 chars).",
        )
        return CommitValidationResult(False, tuple(errors))

    ctype = m.group("type")
    if ctype not in ALLOWED_TYPES:
        errors.append(
            f"type must be one of {sorted(ALLOWED_TYPES)}, got {ctype!r}.",
        )

    subject = m.group("subject")
    if not subject:
        errors.append("Subject must not be empty.")
    elif len(subject) > 72:
        errors.append(f"Subject must be at most 72 characters (got {len(subject)}).")
    elif subject.rstrip().endswith("."):
        errors.append("Subject must not end with a period.")

    if len(lines) > 1:
        if lines[1].strip() != "":
            errors.append("Second line must be blank when a body is present.")

    return CommitValidationResult(len(errors) == 0, tuple(errors))
