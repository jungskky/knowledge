---
name: commit-message-format
description: Validates and formats Git commit messages using Conventional Commits with a fixed type list and scope rules. Use when writing commits, reviewing commit messages, or when the user mentions conventional commits or commit format.
---

# Commit message format

## Rules (canonical)

1. **First line**: `<type>(<scope>): <subject>`
   - `type` must be one of: `feat`, `fix`, `docs`, `chore`, `test`, `refactor`
   - `scope` is required; lowercase letters, numbers, hyphens only; 1–32 characters
   - `subject` is 1–72 characters, no trailing period, imperative mood
2. **Optional body**: blank line after the first line, then wrapped text (each line max 72 chars when wrapped; validation focuses on the header).

The runnable validator lives in `src/skill_sample/commit_skill.py`. Prefer calling `validate_commit_message()` when automating checks.

## Examples

**Valid**

```
feat(auth): add password reset flow
```

```
fix(api): handle empty query string

Return 400 with a clear error payload.
```

**Invalid**

```
added login  (missing type/scope format)
```

```
feat: no scope (scope is required in this project)
```
