import { Chatbot } from "./Chatbot";

export default function App() {
  return (
    <div className="app-shell">
      <header className="app-header">
        <h1>챗봇</h1>
      </header>
      <main className="app-main">
        <Chatbot />
      </main>
    </div>
  );
}
