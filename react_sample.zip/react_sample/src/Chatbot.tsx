import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type KeyboardEvent,
} from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";

export type ChatRole = "user" | "assistant";

export type ChatMessage = {
  id: string;
  role: ChatRole;
  content: string;
};

function createId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

/** 데모용: 실제로는 API 호출로 교체하세요. */
async function fetchAssistantReply(userText: string): Promise<string> {
  await new Promise((r) => setTimeout(r, 400));
  return [
    "다음은 **마크다운** 예시입니다.",
    "",
    "- 목록 항목",
    "- `인라인 코드`",
    "",
    "```ts\nconst x = 1;\n```",
    "",
    "| 열1 | 열2 |",
    "| --- | --- |",
    "| a | b |",
    "",
    userText.length > 0
      ? `입력하신 내용을 인용합니다:\n\n> ${userText}`
      : "",
  ].join("\n");
}

export function Chatbot() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [pending, setPending] = useState(false);
  const listEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = useCallback(() => {
    listEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || pending) return;

    const userMsg: ChatMessage = {
      id: createId(),
      role: "user",
      content: text,
    };
    setInput("");
    setMessages((prev) => [...prev, userMsg]);
    setPending(true);

    try {
      const reply = await fetchAssistantReply(text);
      setMessages((prev) => [
        ...prev,
        { id: createId(), role: "assistant", content: reply },
      ]);
    } finally {
      setPending(false);
    }
  }, [input, pending]);

  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      void send();
    }
  };

  return (
    <section className="chatbot" aria-label="채팅">
      <div className="chatbot-messages" role="log" aria-live="polite">
        {messages.length === 0 && (
          <p className="chatbot-empty">메시지를 입력해 대화를 시작하세요.</p>
        )}
        {messages.map((m) => (
          <article
            key={m.id}
            className={`chatbot-bubble chatbot-bubble--${m.role}`}
          >
            {m.role === "user" ? (
              <p className="chatbot-user-text">{m.content}</p>
            ) : (
              <div className="chatbot-md">
                <ReactMarkdown remarkPlugins={[remarkGfm]}>
                  {m.content}
                </ReactMarkdown>
              </div>
            )}
          </article>
        ))}
        {pending && (
          <div className="chatbot-bubble chatbot-bubble--assistant chatbot-typing">
            답변 작성 중…
          </div>
        )}
        <div ref={listEndRef} />
      </div>

      <div className="chatbot-input-row">
        <textarea
          className="chatbot-input"
          rows={2}
          placeholder="메시지를 입력하세요. (Enter: 전송, Shift+Enter: 줄바꿈)"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={onKeyDown}
          disabled={pending}
          aria-label="메시지 입력"
        />
        <button
          type="button"
          className="chatbot-send"
          onClick={() => void send()}
          disabled={pending || !input.trim()}
        >
          전송
        </button>
      </div>
    </section>
  );
}
