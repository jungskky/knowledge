"""
converter.py
------------
docling의 DocumentConverter를 감싸서 PDF(그 외 docx, pptx, html 등)를
DoclingDocument 객체로 변환하는 역할을 담당한다.

DoclingDocument는 이후 단계(표 추출, chunking, 마크다운 export 등)에서
공통으로 사용되는 핵심 객체이다.
"""

from __future__ import annotations

from pathlib import Path
from typing import Union

from docling.document_converter import DocumentConverter
from docling_core.types.doc.document import DoclingDocument


class PDFConverter:
    """PDF/문서 파일을 DoclingDocument로 변환하는 래퍼 클래스."""

    def __init__(self) -> None:
        # DocumentConverter는 내부적으로 레이아웃 분석, OCR, 표 구조 인식(TableFormer) 등을
        # 파이프라인으로 묶어서 실행한다. 별도 옵션을 주지 않으면 기본 파이프라인을 사용한다.
        self._converter = DocumentConverter()

    def convert(self, source: Union[str, Path]) -> DoclingDocument:
        """
        파일 경로(또는 URL)를 받아 DoclingDocument를 반환한다.

        Parameters
        ----------
        source: 변환할 문서의 경로 또는 URL (PDF, DOCX, PPTX, HTML 등)

        Returns
        -------
        DoclingDocument
        """
        result = self._converter.convert(source)
        return result.document

    def convert_with_result(self, source: Union[str, Path]):
        """
        DoclingDocument뿐 아니라 conv_res 전체(입력 파일 메타데이터 등)가
        필요한 경우를 위한 메서드.
        """
        return self._converter.convert(source)
