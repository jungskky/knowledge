"""
run_example.py
---------------
프로젝트 루트에서 다음과 같이 실행:

    python examples/run_example.py path/to/your.pdf

각 단계를 직접 호출해보는 예제 (파이프라인 전체를 쓰고 싶다면 src/pipeline.py의
run_pipeline()을 바로 사용해도 된다).
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.chunker import DocumentChunker
from src.converter import PDFConverter
from src.table_extractor import TableExtractor


def main(pdf_path: str) -> None:
    # 1) PDF -> DoclingDocument
    converter = PDFConverter()
    document = converter.convert(pdf_path)
    print(f"페이지 수: {len(document.pages)}")

    # 2) 표 추출 (페이지 번호 포함)
    table_extractor = TableExtractor(document)
    tables = table_extractor.extract()
    for t in tables:
        print(f"[표 {t.index + 1}] page={t.page_no}, shape={t.dataframe.shape}")

    # 3) chunking (페이지 번호 포함)
    chunker = DocumentChunker(tokenizer="sentence-transformers/all-MiniLM-L6-v2")
    chunks = chunker.chunk(document)
    for c in chunks[:5]:
        preview = c.text[:80].replace("\n", " ")
        print(f"[chunk {c.index}] page={c.page_range} tokens={c.num_tokens} :: {preview}...")

    # 4) 결과 저장
    output_dir = Path(__file__).resolve().parents[1] / "output"
    table_extractor.save_all(output_dir / "tables")
    table_extractor.save_summary_json(output_dir / "tables.json")
    chunker.save_jsonl(chunks, output_dir / "chunks.jsonl")
    print(f"결과가 {output_dir} 에 저장되었습니다.")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("사용법: python examples/run_example.py <path/to/document.pdf>")
        sys.exit(1)
    main(sys.argv[1])
