설치
bash
cd docling-parser-project
pip install -r requirements.txt
실행 (가장 간단한 방법 — CLI)
bash
python -m src.pipeline path/to/document.pdf --output-dir output

이 한 줄로 변환 → 표 추출 → chunking → 마크다운 저장까지 전부 실행됩니다. 처음 실행할 때는 docling이 레이아웃/표 인식용 모델 가중치를 자동으로 내려받아서(네트워크 필요) 조금 시간이 걸릴 수 있어요.

옵션

--output-dir : 결과 저장 위치 (기본값 output)
--tokenizer : chunking 기준 tokenizer (기본값 sentence-transformers/all-MiniLM-L6-v2, 한국어 문서면 jhgan/ko-sroberta-multitask 추천)
--max-tokens : 청크 하나당 최대 토큰 수 제한
결과물 (output/ 안에 생성됨)
파일	내용
문서명.md	전체 마크다운 (변환이 잘 됐는지 눈으로 검수용)
문서명-tables.json	표 전체 데이터 + 페이지 번호
tables/문서명-01-p3.csv, .html	표별 개별 파일 (파일명에 페이지 번호 포함)
문서명-chunks.jsonl	청크 목록 (텍스트, 페이지 범위, 헤딩, 토큰 수) — 임베딩 파이프라인에 바로 넣으면 됨
문서명-manifest.json	실행 요약 (표/청크 개수, 파일 경로 정리)
코드에서 직접 쓰고 싶을 때
python
from src.converter import PDFConverter
from src.table_extractor import TableExtractor
from src.chunker import DocumentChunker

document = PDFConverter().convert("document.pdf")

tables = TableExtractor(document).extract()      # 표 + 페이지번호
chunks = DocumentChunker().chunk(document)        # 청크 + 페이지번호

for c in chunks:
    print(c.page_range, c.text[:80])   # 예: "7-8", "3. 재무 현황 ..."

가장 먼저 갖고 계신 PDF 하나로 CLI 명령 한 줄 돌려보시고, 표/청크가 원하는 형태로 나오는지 확인해보시는 걸 추천드려요.