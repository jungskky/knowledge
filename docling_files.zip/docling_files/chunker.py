"""
chunker.py
----------
docling의 HybridChunker를 사용해 DoclingDocument를 RAG용 청크로 분할하고,
각 청크가 원본 문서의 몇 페이지에서 왔는지(page_no) 함께 기록한다.

HybridChunker는 문서의 구조(섹션/표/리스트 등)를 기준으로 1차 분할한 뒤,
지정한 tokenizer의 토큰 한도에 맞춰 필요한 경우 추가로 split/merge를
수행하는 방식이다(HierarchicalChunker + 토큰 인식 후처리).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Union

from docling.chunking import HybridChunker
from docling_core.types.doc.document import DoclingDocument


@dataclass
class DocChunk:
    """페이지 번호 메타데이터가 포함된 청크 1개."""

    index: int
    text: str
    headings: List[str] = field(default_factory=list)
    page_numbers: List[int] = field(default_factory=list)
    num_tokens: Optional[int] = None

    @property
    def page_range(self) -> str:
        if not self.page_numbers:
            return "unknown"
        lo, hi = min(self.page_numbers), max(self.page_numbers)
        return f"{lo}" if lo == hi else f"{lo}-{hi}"

    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "text": self.text,
            "headings": self.headings,
            "page_numbers": self.page_numbers,
            "page_range": self.page_range,
            "num_tokens": self.num_tokens,
        }


class DocumentChunker:
    """DoclingDocument를 페이지번호가 포함된 청크 리스트로 변환한다."""

    def __init__(
        self,
        tokenizer: Optional[str] = "sentence-transformers/all-MiniLM-L6-v2",
        max_tokens: Optional[int] = None,
        merge_peers: bool = True,
    ) -> None:
        """
        Parameters
        ----------
        tokenizer:
            HuggingFace 토크나이저 이름. 실제 임베딩/생성 모델의 토크나이저와
            맞춰주는 것이 좋다 (예: "BAAI/bge-small-en-v1.5", "jhgan/ko-sroberta-multitask" 등).
        max_tokens:
            청크 당 최대 토큰 수. None이면 tokenizer의 기본 max_length를 사용한다.
        merge_peers:
            토큰 한도 내에서 인접한 작은 청크들을 병합할지 여부.
        """
        kwargs = {"merge_peers": merge_peers}
        if tokenizer is not None:
            kwargs["tokenizer"] = tokenizer
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens

        self._chunker = HybridChunker(**kwargs)

    def chunk(self, document: DoclingDocument) -> List[DocChunk]:
        """DoclingDocument를 청크 리스트로 분할한다 (페이지 번호 포함)."""
        chunk_iter = self._chunker.chunk(dl_doc=document)

        results: List[DocChunk] = []
        for idx, chunk in enumerate(chunk_iter):
            page_numbers = self._extract_page_numbers(chunk)
            headings = list(getattr(chunk.meta, "headings", None) or [])

            # contextualize()는 헤딩/캡션 등이 포함된, 임베딩에 바로 넣기 좋은 형태의 텍스트를 만들어준다.
            try:
                text = self._chunker.contextualize(chunk)
            except Exception:
                text = chunk.text

            num_tokens = None
            tokenizer = getattr(self._chunker, "tokenizer", None)
            if tokenizer is not None:
                try:
                    num_tokens = tokenizer.count_tokens(text)
                except Exception:
                    num_tokens = None

            results.append(
                DocChunk(
                    index=idx,
                    text=text,
                    headings=headings,
                    page_numbers=page_numbers,
                    num_tokens=num_tokens,
                )
            )

        return results

    @staticmethod
    def _extract_page_numbers(chunk) -> List[int]:
        """청크가 참조하는 doc_items의 provenance에서 페이지 번호들을 수집한다."""
        pages = set()
        doc_items = getattr(chunk.meta, "doc_items", None) or []
        for item in doc_items:
            for prov in getattr(item, "prov", None) or []:
                page_no = getattr(prov, "page_no", None)
                if page_no is not None:
                    pages.add(page_no)
        return sorted(pages)

    def save_jsonl(self, chunks: List[DocChunk], output_path: Union[str, Path]) -> Path:
        """청크 리스트를 JSON Lines 형식으로 저장한다 (임베딩 파이프라인 입력으로 바로 사용 가능)."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with output_path.open("w", encoding="utf-8") as f:
            for c in chunks:
                f.write(json.dumps(c.to_dict(), ensure_ascii=False) + "\n")
        return output_path
