# Docling Parser Project

[docling](https://github.com/docling-project/docling) 라이브러리를 이용해
PDF(그 외 DOCX/PPTX/HTML 등)에서 **표 추출**, **페이지 번호 매핑**,
**RAG용 chunking**을 한 번에 처리하는 프로젝트입니다.

## 주요 기능

- **표 추출**: TableFormer 기반 구조 인식으로 표를 `pandas.DataFrame`으로 변환,
  CSV/HTML/JSON으로 저장하며 각 표가 몇 페이지에 있었는지 함께 기록합니다.
- **페이지 번호 추적**: 표뿐 아니라 chunk 단위로도 원본 페이지 번호(또는 범위)를 매핑합니다.
  근거 추적(citation)이 필요한 RAG 시스템에 바로 활용할 수 있습니다.
- **Chunking**: `HybridChunker`를 사용해 문서 구조(섹션/표/리스트)를 존중하면서
  지정한 tokenizer의 토큰 한도에 맞춰 청크를 생성합니다. 결과는 JSONL로 저장됩니다.

## 프로젝트 구조

```
docling-parser-project/
├── requirements.txt
├── src/
│   ├── converter.py        # PDF -> DoclingDocument 변환
│   ├── table_extractor.py  # 표 추출 + 페이지번호
│   ├── chunker.py          # HybridChunker + 페이지번호 매핑
│   └── pipeline.py         # 전체 파이프라인 (CLI 진입점)
├── examples/
│   └── run_example.py      # 단계별 사용 예제
└── output/                 # 실행 결과가 저장되는 디렉토리
```

## 설치

```bash
pip install -r requirements.txt
```

> docling은 최초 실행 시 레이아웃 분석/OCR/표 구조 인식용 모델 가중치를
> 자동으로 다운로드합니다 (네트워크 필요, 수백 MB 수준).

## 사용법

### CLI로 전체 파이프라인 실행

```bash
python -m src.pipeline path/to/document.pdf --output-dir output \
    --tokenizer sentence-transformers/all-MiniLM-L6-v2
```

실행 후 `output/` 디렉토리에 다음이 생성됩니다.

- `document.md` — 문서 전체 마크다운 (검수용)
- `document-tables.json` — 표 전체 메타데이터 + 데이터 (페이지 번호 포함)
- `tables/document-01-p3.csv`, `.html` — 표별 CSV/HTML (페이지 번호가 파일명에 포함)
- `document-chunks.jsonl` — 청크 리스트 (텍스트 + 페이지 범위 + 헤딩 + 토큰 수)
- `document-manifest.json` — 실행 요약 (표 개수, 청크 개수, 결과 파일 경로 등)

### 코드에서 직접 사용

```python
from src.converter import PDFConverter
from src.table_extractor import TableExtractor
from src.chunker import DocumentChunker

document = PDFConverter().convert("document.pdf")

# 표 + 페이지번호
tables = TableExtractor(document).extract()
for t in tables:
    print(t.index, t.page_no, t.dataframe.shape)

# chunk + 페이지번호
chunks = DocumentChunker(tokenizer="BAAI/bge-small-en-v1.5").chunk(document)
for c in chunks:
    print(c.page_range, c.text[:80])
```

### chunk의 JSONL 출력 예시

```json
{"index": 12, "text": "...", "headings": ["3. 재무 현황"], "page_numbers": [7, 8], "page_range": "7-8", "num_tokens": 184}
```

## 커스터마이징

- **tokenizer 변경**: 실제 사용할 임베딩 모델의 tokenizer로 맞추는 것을 권장합니다
  (예: 한국어 문서라면 `jhgan/ko-sroberta-multitask` 등).
- **max_tokens 조정**: `DocumentChunker(max_tokens=...)`로 청크 최대 길이를 제어합니다.
- **다단 레이아웃 문서**: docling은 레이아웃 분석 단계에서 컬럼을 인식하여 읽기 순서를
  자동으로 정렬합니다. 별도 설정 없이 대부분의 2단 레이아웃 PDF에 적용 가능합니다.

## 참고

- Docling 공식 문서: https://docling-project.github.io/docling/
- HybridChunker 개념: https://docling-project.github.io/docling/concepts/chunking/
