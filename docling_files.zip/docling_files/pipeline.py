"""
pipeline.py
-----------
converter -> table_extractor -> chunker 를 순서대로 실행하는 end-to-end 파이프라인.

사용 예:
    python -m src.pipeline path/to/document.pdf --output-dir output
"""

from __future__ import annotations

import argparse
import json
import logging
from pathlib import Path

from src.chunker import DocumentChunker
from src.converter import PDFConverter
from src.table_extractor import TableExtractor

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)


def run_pipeline(
    source: str,
    output_dir: str = "output",
    tokenizer: str = "sentence-transformers/all-MiniLM-L6-v2",
    max_tokens: int | None = None,
) -> dict:
    """
    문서 하나를 받아 다음을 수행하고 output_dir에 결과를 저장한다.

    1. PDF -> DoclingDocument 변환 (레이아웃/표 구조 인식 포함)
    2. 표 추출 (페이지 번호 포함, CSV/HTML/JSON으로 저장)
    3. 페이지 번호가 포함된 chunk 생성 (JSONL로 저장)
    4. 문서 전체를 마크다운으로 저장 (검수용)

    Returns
    -------
    각 결과물의 경로를 담은 dict
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    doc_name = Path(source).stem

    log.info("1/4 문서 변환 중: %s", source)
    converter = PDFConverter()
    document = converter.convert(source)

    log.info("2/4 표 추출 중 (표 %d개 발견)", len(document.tables))
    table_extractor = TableExtractor(document)
    table_dir = output_dir / "tables"
    table_paths = table_extractor.save_all(table_dir, prefix=doc_name)
    table_summary_path = table_extractor.save_summary_json(
        output_dir / f"{doc_name}-tables.json"
    )

    log.info("3/4 chunking 수행 중 (tokenizer=%s)", tokenizer)
    chunker = DocumentChunker(tokenizer=tokenizer, max_tokens=max_tokens)
    chunks = chunker.chunk(document)
    chunks_path = chunker.save_jsonl(chunks, output_dir / f"{doc_name}-chunks.jsonl")
    log.info("   -> 청크 %d개 생성", len(chunks))

    log.info("4/4 마크다운 저장 중")
    markdown_path = output_dir / f"{doc_name}.md"
    markdown_path.write_text(document.export_to_markdown(), encoding="utf-8")

    result = {
        "document": str(source),
        "num_pages": getattr(document, "num_pages", lambda: None)()
        if callable(getattr(document, "num_pages", None))
        else None,
        "num_tables": len(document.tables),
        "num_chunks": len(chunks),
        "outputs": {
            "markdown": str(markdown_path),
            "tables_json": str(table_summary_path),
            "table_files": [str(p) for p in table_paths],
            "chunks_jsonl": str(chunks_path),
        },
    }

    manifest_path = output_dir / f"{doc_name}-manifest.json"
    manifest_path.write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    log.info("완료. manifest: %s", manifest_path)

    return result


def main() -> None:
    parser = argparse.ArgumentParser(
        description="docling 기반 문서 파서: 표 추출 + 페이지번호 + chunking"
    )
    parser.add_argument("source", help="변환할 문서 경로 (PDF, DOCX, PPTX, HTML 등)")
    parser.add_argument("--output-dir", default="output", help="결과물 저장 디렉토리")
    parser.add_argument(
        "--tokenizer",
        default="sentence-transformers/all-MiniLM-L6-v2",
        help="chunking에 사용할 HuggingFace tokenizer 이름",
    )
    parser.add_argument(
        "--max-tokens", type=int, default=None, help="청크 당 최대 토큰 수"
    )
    args = parser.parse_args()

    run_pipeline(
        source=args.source,
        output_dir=args.output_dir,
        tokenizer=args.tokenizer,
        max_tokens=args.max_tokens,
    )


if __name__ == "__main__":
    main()
