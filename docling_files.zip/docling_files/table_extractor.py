"""
table_extractor.py
-------------------
DoclingDocument에서 표(Table)를 추출하고, 각 표가 속한 페이지 번호를 함께 기록한다.

docling은 표 구조 인식(TableFormer)을 통해 셀 병합/구조를 유지한 채
pandas.DataFrame으로 변환할 수 있으며, table.prov[0].page_no로
표가 위치한 페이지 번호를 알 수 있다.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Union

import pandas as pd
from docling_core.types.doc.document import DoclingDocument


@dataclass
class ExtractedTable:
    """추출된 표 1개를 표현하는 데이터 클래스."""

    index: int
    page_no: Optional[int]
    dataframe: pd.DataFrame = field(repr=False)
    caption: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "index": self.index,
            "page_no": self.page_no,
            "caption": self.caption,
            "n_rows": self.dataframe.shape[0],
            "n_cols": self.dataframe.shape[1],
            "rows": self.dataframe.to_dict(orient="records"),
        }


class TableExtractor:
    """DoclingDocument로부터 표를 추출하고 다양한 포맷으로 저장한다."""

    def __init__(self, document: DoclingDocument) -> None:
        self.document = document

    def extract(self) -> List[ExtractedTable]:
        """문서에 포함된 모든 표를 페이지 번호와 함께 추출한다."""
        extracted: List[ExtractedTable] = []

        for idx, table in enumerate(self.document.tables):
            page_no = None
            if table.prov:
                # 표가 여러 페이지에 걸쳐 있을 수 있으므로 첫 provenance의 페이지를 대표값으로 사용
                page_no = table.prov[0].page_no

            caption = None
            if getattr(table, "captions", None):
                try:
                    caption = table.caption_text(self.document)
                except Exception:
                    caption = None

            # docling-core 최신 버전은 export_to_dataframe(doc=...) 형태를 권장(구버전 호환을 위해 예외 처리)
            try:
                df = table.export_to_dataframe(doc=self.document)
            except TypeError:
                df = table.export_to_dataframe()

            extracted.append(
                ExtractedTable(index=idx, page_no=page_no, dataframe=df, caption=caption)
            )

        return extracted

    def save_all(self, output_dir: Union[str, Path], prefix: str = "table") -> List[Path]:
        """추출한 표들을 CSV/HTML로 저장하고 저장된 경로 목록을 반환한다."""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        saved_paths: List[Path] = []
        for t in self.extract():
            page_tag = f"p{t.page_no}" if t.page_no is not None else "pUnknown"
            base = output_dir / f"{prefix}-{t.index + 1:02d}-{page_tag}"

            csv_path = base.with_suffix(".csv")
            t.dataframe.to_csv(csv_path, index=False)
            saved_paths.append(csv_path)

            html_path = base.with_suffix(".html")
            html_path.write_text(t.dataframe.to_html(index=False), encoding="utf-8")
            saved_paths.append(html_path)

        return saved_paths

    def save_summary_json(self, output_path: Union[str, Path]) -> Path:
        """모든 표의 메타데이터(+데이터)를 하나의 JSON 파일로 저장한다."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        summary = [t.to_dict() for t in self.extract()]
        output_path.write_text(
            json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        return output_path
